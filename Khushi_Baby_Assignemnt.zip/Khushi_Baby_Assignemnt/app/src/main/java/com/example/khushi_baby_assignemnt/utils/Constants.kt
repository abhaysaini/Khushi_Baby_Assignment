package com.example.khushi_baby_assignemnt.utils

object Constants {
     const val BASE_URL = "https://api.themoviedb.org/3/"
}